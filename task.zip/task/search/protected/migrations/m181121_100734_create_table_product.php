<?php

class m181121_100734_create_table_product extends CDbMigration
{
	public function up()
	{
             $this->createTable('product', array(
                'id' => 'pk',
                'name'=>'string NOT NULL',
                 ), 'ENGINE=InnoDB');
	}

	public function down()
	{
		echo "m181121_100734_create_table_product does not support migration down.\n";
		return false;
	}

	/*
	// Use safeUp/safeDown to do migration with transaction
	public function safeUp()
	{
	}

	public function safeDown()
	{
	}
	*/
}
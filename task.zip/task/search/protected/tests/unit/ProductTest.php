<?php

class ProductTest extends CWebTestCase
{
    public $fixtures = array(
        'product'    => 'Product',
    );
    protected function testProductSearch($test="test"){
            
            $products=  Product::model()->findAll("name=:val", array(':val'=>$test));
            if(count($products)>0){
                foreach ($products as $product){
                    $this->assertEquals($test,$product->name);
                }
            }
        }

}

